Nome = Emanuel Ribeiro Ferreira Nunes e Souza

Descrição = Projeto criado para armazenar dados de alunos de uma Faculdade 

Models Criados :
Aluno: Contém Nome, idade, email;
Materia: Contém NomeDaMateria, descricao, duracao;
Matricula: Contém Alunoo (fk), curso (fk), data_matricula

Tecnologias Utilizadas
O projeto foi desenvolvido usando:
Python; 
Django;
SQLite (banco padrão do Django);
Django Admin;

Instruções para rodar:
Para rodar basta apenas entrar no terminal e escrever: 
python manage.py runserver
após isso colocar na url 127.0.0.1:8000/admin
e colocar o usuario e senha "emanuel"
