from django.contrib import admin
from .models import Aluno
from .models import Materia
from .models import Matricula

# Register your models here.
admin.site.site_header = "Administração do Sistema de Cadastros"         
admin.site.site_title = "Administração de Cadastros"                     
admin.site.register(Aluno)                                              
admin.site.register(Materia)                                             
admin.site.register(Matricula)    
