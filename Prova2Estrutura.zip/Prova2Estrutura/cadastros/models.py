from django.db import models

# Create your models here.
class Aluno(models.Model):
    nome = models.CharField(max_length=100)                                 
    idade = models.IntegerField()                                                               
    email = models.EmailField(unique=True)                                  

    def __str__(self):                                                      
        return self.nome                                                   


class Materia(models.Model):
    NomeDaMateria = models.CharField(max_length=200)                               
    descricao = models.TextField()                                                         
    duracao = models.IntegerField(help_text="Duração em horas")             

    def __str__(self):                                                      
        return self.titulo                                                  
    
    
class Matricula(models.Model):
    aluno = models.ForeignKey(Aluno, on_delete=models.CASCADE)              
    curso = models.ForeignKey(Materia, on_delete=models.CASCADE)              
    data_matricula = models.DateField(auto_now_add=True)                    

    def __str__(self):                                                     
        return f"{self.aluno.nome} matriculado em {self.curso.titulo}"      
